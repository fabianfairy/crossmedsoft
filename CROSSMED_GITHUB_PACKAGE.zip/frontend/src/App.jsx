import React from 'react';
function App() { return <h1>Crossmed MEDSYS</h1>; }
# CROSSMED MEDSYS 2025

## How to Run

1. `cd backend` → `npm install` → `npm start`
2. `cd frontend` → `npm install` → `npm run dev`
3. Import SQL from `sql/`

## Description
Web version of Crossmed MEDSYS with Node.js, React, and MySQL.
// Node.js backend entry point
const express = require('express');